﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace HRM
{
    public partial class Form10 : Form
    {
        OleDbConnection conn;//for built connection between form10 and data base
        OleDbCommand cmd;
        OleDbDataAdapter dataAdapter;//for implimentation of quries
        OleDbDataReader reader;
        DataTable dt;// for get table of data base
        public Form10()
        {
            InitializeComponent();
        }

        void Zubair8571()
        {
            conn = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\\Users\\PMLS\\Desktop\\HRM.accdb");
            dt = new DataTable();
            dataAdapter = new OleDbDataAdapter("SELECT * FROM applicants", conn);
            conn.Open();// for open database
            dataAdapter.Fill(dt);
            dataGridView1.DataSource = dt;//for print of database on gridview 
            conn.Close();// for clodse database connection
        }
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
           
            
                if (e.RowIndex >= 0) // Make sure a valid row is selected
                {
                    DataGridViewRow selectedRow = dataGridView1.Rows[e.RowIndex];

                    // Get the data from the selected row
                    string id = selectedRow.Cells["ID"].Value.ToString();
                    string name = selectedRow.Cells["name"].Value.ToString();
                    string fname = selectedRow.Cells["fname"].Value.ToString();
                    string cnic = selectedRow.Cells["CNIC"].Value.ToString();
                    string phone = selectedRow.Cells["phone"].Value.ToString();
                    string email = selectedRow.Cells["email"].Value.ToString();
                    string district = selectedRow.Cells["destrict"].Value.ToString();
                    string post = selectedRow.Cells["post"].Value.ToString();
                    DateTime dob = Convert.ToDateTime(selectedRow.Cells["DOB"].Value);
                    string gender = selectedRow.Cells["gender"].Value.ToString();
                    string maritalStatus = selectedRow.Cells["mstatus"].Value.ToString();
                    string area = selectedRow.Cells["area"].Value.ToString();
                    string nationality = selectedRow.Cells["nationality"].Value.ToString();
                    string education = selectedRow.Cells["education"].Value.ToString();
                    string experience = selectedRow.Cells["experience"].Value.ToString();

                // Open Form11 and pass the data
                //  Form11 form = new Form11();
                //     Form11.SetData(id, name, fname, cnic, phone, email, district, post, dob, gender, maritalStatus, area, nationality, education, experience);
                //       form.ShowDialog();

                Form11 form11 = new Form11();

                // Call SetData method on the instance
                form11.SetData(id, name, fname, cnic, phone, email, district, post, dob, gender, maritalStatus, area, nationality, education, experience);

                // Open Form11
                form11.Show();
            }
            

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 form = new Form1();
            form.ShowDialog();
            this.Close();
        }

        private void Form10_Load(object sender, EventArgs e)
        {
            Zubair8571();
        }

        private void button5_Click(object sender, EventArgs e)
        {

        }
    }
}
