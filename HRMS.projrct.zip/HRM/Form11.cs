﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HRM
{
    public partial class Form11 : Form
    {
        public string EmployeeName
        {
            get { return namebox.Text; }
        }


        OleDbConnection connection = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\PMLS\Desktop\HRM.accdb");

        private void InsertData()
        {
            string query = "INSERT INTO employ (EmpName, fname, CNIC, DOB, phone, Email, Area, gender, Mstatus, District, Nationality, education, experience, startdate, post, scale) " +
                           "VALUES (@EmpName, @fname, @CNIC, @DOB, @phone, @Email, @Area, @gender, @Mstatus, @District, @Nationality, @education, @experience, @startdate, @post, @scale)";

            using (OleDbCommand cmd = new OleDbCommand(query, connection))
            {
                cmd.Parameters.AddWithValue("@EmpName", namebox.Text);
                cmd.Parameters.AddWithValue("@fname", fnamebox.Text);
                cmd.Parameters.AddWithValue("@CNIC", cnicbox.Text);
                cmd.Parameters.AddWithValue("@DOB", dateTimePicker1.Value);
                cmd.Parameters.AddWithValue("@phone", phonebox.Text);
                cmd.Parameters.AddWithValue("@Email", emailbox.Text);
                cmd.Parameters.AddWithValue("@Area", areabox.Text);
                cmd.Parameters.AddWithValue("@gender", genderbox.Text);
                cmd.Parameters.AddWithValue("@Mstatus", mstatusbox.Text);
                cmd.Parameters.AddWithValue("@District", districtbox.Text);
                cmd.Parameters.AddWithValue("@Nationality", nationalitybox.Text);
                cmd.Parameters.AddWithValue("@education", educationbox.Text);
                cmd.Parameters.AddWithValue("@experience", experiencebox.Text);
                cmd.Parameters.AddWithValue("@startdate", DateTime.Now); // You might want to get this from your DateTimePicker
                cmd.Parameters.AddWithValue("@post", postbox.Text);
                cmd.Parameters.AddWithValue("@scale", scalebox.Text); // Assuming you have a control named scalebox

                connection.Open();
                int rowsAffected = cmd.ExecuteNonQuery();
                connection.Close();

                if (rowsAffected > 0)
                {
     
          Form12 form12 = new Form12();
        form12.EmployeeName = namebox.Text;

        
        form12.Show();


                }
                else
                {
                    MessageBox.Show("Failed to insert data.");
                }
            }
        }

      
        public Form11()
        {
            InitializeComponent();
        }

        private void Form11_Load(object sender, EventArgs e)
        {
            
        }
        public void SetData(string id, string name, string fname, string cnic, string phone, string email, string district, string post, DateTime dob, string gender, string maritalStatus, string area, string nationality, string education, string experience)
        {
            idbox.Text = id;
            namebox.Text = name;
            fnamebox.Text = fname;
            cnicbox.Text = cnic;
            phonebox.Text = phone;
            emailbox.Text = email;
            districtbox.Text = district;
            postbox.Text = post;
            dateTimePicker1.Value = dob;
            genderbox.Text = gender;
            mstatusbox.Text = maritalStatus;
            areabox.Text = area;
            nationalitybox.Text = nationality;
            educationbox.Text = education;
            experiencebox.Text = experience;
        }


        private void idbox_TextChanged(object sender, EventArgs e)
        {

        }

        private void label14_Click(object sender, EventArgs e)
        {

        }

        private void label18_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
            Form1 form = new Form1();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            InsertData();
        }
    }
}
