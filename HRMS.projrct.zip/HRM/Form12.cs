﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;
using System.Data.OleDb;
namespace HRM
{
    public partial class Form12 : Form
    { 
            public string EmployeeName
            {
                set { textbox1.Text = value; }
            }

        public Form12()
        {
            InitializeComponent();
        }

        private void idbox_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {   
            string username = textbox1.Text;
                string password = textbox2.Text;
                string userType = textbox3.Text;

                
                string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\PMLS\Desktop\HRM.accdb";
                string query = "INSERT INTO users (username, password, usertype) VALUES (@Username, @Password, @UserType)";

                using (OleDbConnection connection = new OleDbConnection(connectionString))
                using (OleDbCommand command = new OleDbCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Username", username);
                    command.Parameters.AddWithValue("@Password", password);
                    command.Parameters.AddWithValue("@UserType", userType);

                    try
                    {
                        connection.Open();
                        int rowsAffected = command.ExecuteNonQuery();
                        connection.Close();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("The New employ hiered  successfully.");
                        }
                        else
                        {
                            MessageBox.Show("Failed to add user.");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("An error occurred please Try again:  " + ex.Message);
                    }
                }
            }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
            Form1 form = new Form1();   
        }

        private void Form12_Load(object sender, EventArgs e)
        {

        }
    }
    }
