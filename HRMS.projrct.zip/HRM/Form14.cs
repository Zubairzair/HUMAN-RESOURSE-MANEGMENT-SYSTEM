﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace HRM
{
    public partial class Form14 : Form
    {

        private OleDbConnection connection = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\PMLS\Desktop\HRM.accdb");
  
        public Form14()
        {
            InitializeComponent();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            {
                string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\PMLS\Desktop\HRM.accdb";
                // Update the connection string with the correct path to your Access database file.

                string textbox1_value = "value1";
                string textbox2_value = "value2";
                string textbox3_value = "value3";
                DateTime datetimepicker1_value = DateTime.Now;
                string textbox4_value = "value4";
                string textbox5_value = "value5";

                string query = "INSERT INTO jobs (ID, jobtitle, seats, lastdate, education, payment) VALUES (@ID, @jobtitle, @seats, @lastdate, @education, @payment)";

                using (OleDbConnection connection = new OleDbConnection(connectionString))
                {
                    using (OleDbCommand command = new OleDbCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@ID", textbox1_value);
                        command.Parameters.AddWithValue("@jobtitle", textbox2_value);
                        command.Parameters.AddWithValue("@seats", textbox3_value);
                        command.Parameters.AddWithValue("@lastdate", datetimepicker1_value);
                        command.Parameters.AddWithValue("@education", textbox4_value);
                        command.Parameters.AddWithValue("@payment", textbox5_value);

                        try
                        {
                            connection.Open();
                            int rowsAffected = command.ExecuteNonQuery();
                            Console.WriteLine($"{rowsAffected} row(s) inserted.");
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine("Error: " + ex.Message);
                        }
                    }

                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            {
                // Connection string to your Access database
                string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\PMLS\Desktop\HRM.accdb";

                // Values from your form controls
                string textbox1Value = "NewValue1"; // Get this value from textbox1
                string textbox2Value = "NewValue2"; // Get this value from textbox2
                string textbox3Value = "NewValue3"; // Get this value from textbox3
                DateTime datetimepicker1Value = DateTime.Now; // Get this value from datetimepicker1
                string textbox4Value = "NewValue4"; // Get this value from textbox4
                string textbox5Value = "NewValue5"; // Get this value from textbox5

                try
                {
                    // Create connection
                    using (OleDbConnection connection = new OleDbConnection(connectionString))
                    {
                        // Open connection
                        connection.Open();

                        // SQL UPDATE command
                        string sql = "UPDATE jobs SET jobtitle = @jobtitle, seats = @seats, lastdate = @lastdate, education = @education, payment = @payment WHERE ID = @ID";

                        // Create command with parameters
                        using (OleDbCommand command = new OleDbCommand(sql, connection))
                        {
                            // Add parameters
                            command.Parameters.AddWithValue("@jobtitle", textbox2Value);
                            command.Parameters.AddWithValue("@seats", textbox3Value);
                            command.Parameters.AddWithValue("@lastdate", datetimepicker1Value);
                            command.Parameters.AddWithValue("@education", textbox4Value);
                            command.Parameters.AddWithValue("@payment", textbox5Value);
                            command.Parameters.AddWithValue("@ID", textbox1Value);

                            // Execute command
                            int rowsAffected = command.ExecuteNonQuery();

                            Console.WriteLine($"{rowsAffected} row(s) updated.");
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error: " + ex.Message);
                }
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            string connectionString = @"""Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\PMLS\Desktop\HRM.accdb";

            // Value from your form control
            string textbox1Value = "Value1"; // Get this value from textbox1 (assuming it contains the ID of the row you want to delete)

            try
            {
                // Create connection
                using (OleDbConnection connection = new OleDbConnection(connectionString))
                {
                    // Open connection
                    connection.Open();

                    // SQL DELETE command
                    string sql = "DELETE FROM jobs WHERE ID = @ID";

                    // Create command with parameter
                    using (OleDbCommand command = new OleDbCommand(sql, connection))
                    {
                        // Add parameter
                        command.Parameters.AddWithValue("@ID", textbox1Value);

                        // Execute command
                        int rowsAffected = command.ExecuteNonQuery();

                        Console.WriteLine($"{rowsAffected} row(s) deleted.");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
        }

        private void Form14_Load(object sender, EventArgs e)
        {
            try
            {
                string query = "SELECT ID, jobtitle, seats, lastdate, education, payment FROM jobs";
                OleDbDataAdapter adapter = new OleDbDataAdapter(query, connection);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);
                dataGridView1.DataSource = dataTable;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow selectedRow = dataGridView1.Rows[e.RowIndex];

                // Assuming column order is: ID, jobtitle, seats, lastdate, education, payment
                textbox1.Text = selectedRow.Cells["ID"].Value.ToString();
                textBox2.Text = selectedRow.Cells["jobtitle"].Value.ToString();
                textbox3.Text = selectedRow.Cells["seats"].Value.ToString();
                dateTimePicker1.Value = Convert.ToDateTime(selectedRow.Cells["lastdate"].Value);
                textbox4.Text = selectedRow.Cells["education"].Value.ToString();
                textbox5.Text = selectedRow.Cells["payment"].Value.ToString();
            }


        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
            Form1 form = new Form1();   
            form.ShowDialog();  
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
      

