﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace HRM
{
    public partial class Form2 : Form
    {
        private string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\PMLS\Desktop\HRM.accdb";

        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox1.Focus();
        }

        private void button1_Click(object sender, EventArgs e)
        {
          //  this.Close();   
            Form1 form = new Form1();
            form.ShowDialog();
            this.Close();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox1.Text =="Zair" && textBox2.Text =="8571")
            {
              //  this.Close();
                Form7 form = new Form7();   
                form.ShowDialog();
                this.Close();
            }
            else if (textBox1.Text =="umar" && textBox2.Text=="1234")
            {
               // this.Close();
Form8 form = new Form8();   
                form.ShowDialog();
                this.Close();   
            }
            else if(textBox1.Text =="" ||textBox2.Text=="")
            {
                MessageBox.Show("You cannot enter empty space , Please enter both name and passward " +
                    "Thank you \n \n " +
                    "  معذرت ، آپ خالی جگہ نہیں چھوڑسکتے " +
                    "\n " +
                    " نام اور پاسورڈ دونوں لکھیں ، شکریہ  ");
                textBox1.Clear();
                textBox2.Clear();
                textBox1.Focus();

            }
            else 
            {
                string username = textBox1.Text;
                string password = textBox2.Text;
                string query = "SELECT usertype FROM users WHERE username = @Username AND password = @Password";

                using (OleDbConnection connection = new OleDbConnection(connectionString))
                using (OleDbCommand command = new OleDbCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Username", username);
                    command.Parameters.AddWithValue("@Password", password);

                    try
                    {
                        connection.Open();
                        object userType = command.ExecuteScalar();
                        connection.Close();

                        if (userType != null)
                        {
                            if (userType.ToString() == "admin")
                            {
                                Form7 form7 = new Form7();
                                form7.Show();
                                this.Close();
                            }
                            else if (userType.ToString() == "user")
                            {
                               
                                
                                Form8 form8 = new Form8();   
                                form8.Show();
                                this.Close();
                            }
                        }
                        else
                        {
                            MessageBox.Show("Username or password incorrect.");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("An error occurred: " + ex.Message);
                    }
                }
            }
        }
        

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
       
            {
                // Toggle password visibility based on the state of the checkbox
                textBox2.PasswordChar = checkBox1.Checked ? '\0' : '*';
            }

         
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
