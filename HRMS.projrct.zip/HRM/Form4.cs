﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using System.Data.SqlClient;

namespace HRM
{
    public partial class Form4 : Form
    {
        OleDbConnection conn;//for built connection between form4 and data base
        OleDbCommand cmd;
        OleDbDataAdapter dataAdapter;//for implimentation of quries
        OleDbDataReader reader;
        DataTable dt;// for get table of data base
        public Form4()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
           
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
          
            Form1 form = new Form1();
            form.ShowDialog();
            this.Close();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

     /*   private void button1_Click(object sender, EventArgs e)
        {
            string gender = "";
            string maritalStatus = "";
            string area = "";

           

            // Check gender
            if (rbmale.Checked)
            {
                gender = "Male";
            }
            else if (rbfemale.Checked)
            {
                gender = "Female";
            }
            else
            {
                MessageBox.Show("Please select your gender.");
                return; // Exit the method early if gender is not selected
            }

            // Check marital status
            if (rbsingle.Checked)
            {
                maritalStatus = "Single";
            }
            else if (rbmarried.Checked)
            {
                maritalStatus = "Married";
            }
            else
            {
                MessageBox.Show("Please select your marital status.");
                return; // Exit the method early if marital status is not selected
            }


            // Now, all selections are made
            // You can proceed to insert values into the database
            InsertIntoDatabase(gender, maritalStatus, area);
        }

     //   private void InsertIntoDatabase(string gender, string maritalStatus, string area)
     //   {
            // Insert values into the database
            // Your database insertion logic goes here
    //    }

        */
          private  void button1_Click(object sender, EventArgs e)
        { 
               string gender = "";
       
               if (rbmale.Checked)
               {
                   gender = "Male";
               }
               else if (rbfemale.Checked)
               {
                   gender = "Female";
               }
               else
               {
                   MessageBox.Show( "Plese Select your gender /n /n " +
                       "  معذرت، آپ نے اپنی جنس نہیں منتخب کی");
               }

           
            
           }

        private void InsertIntoDatabase(string gender, string maritalStatus,string Area)
        {
           

            string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\PMLS\Desktop\HRM.accdb;";

            using (OleDbConnection connection = new OleDbConnection(connectionString))
            {
                string query = "INSERT INTO applicants (name, fname, CNIC,phone, email, destrict,post,DOB,gender, mstatus,area, nationality, education, experience) VALUES (@Name,@FNAME,@cnic,@PHONE,@Email,@District,@Post,@dob,@GENDER,@Mstatus,@Area,@Nationality,@EDUCATION,@EXPERIENCE)";
                using (OleDbCommand command = new OleDbCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Name", nambox.Text);
                    command.Parameters.AddWithValue("@FNAME", fnamebox.Text);
                    command.Parameters.AddWithValue(",@cnic", cnicbox.Text);
                    command.Parameters.AddWithValue("@PHONE", phonebox.Text);
                    command.Parameters.AddWithValue("@Email", emailbox.Text);
                    command.Parameters.AddWithValue("@District", districtbox.Text);
                    command.Parameters.AddWithValue("@Post", postbox.Text);
                    command.Parameters.AddWithValue("@dob", dateTimePicker1);
                    command.Parameters.AddWithValue("@GENDER", gender);
                    command.Parameters.AddWithValue("@Mstatus", maritalStatus);
                    command.Parameters.AddWithValue("@Area", Area );
                    command.Parameters.AddWithValue("@Nationality", nationalitybox.Text);
                    command.Parameters.AddWithValue("@EDUCATION", educationbox.Text);
                    command.Parameters.AddWithValue("@EXPERIENCE", experiencebox.Text);

                    connection.Open();
                    int rowsAffected = command.ExecuteNonQuery();
                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Congradulations, your Data inserted successfuly.Click Ok to view");
                        nambox.Clear();
                        fnamebox.Clear();
                        cnicbox.Clear();
                        phonebox.Clear();
                        emailbox.Clear();
                        districtbox.Clear();
                        postbox.Clear();
                        nationalitybox.Clear();
                        educationbox.Clear();
                        experiencebox.Clear();
                    }
                    else
                    {
                        MessageBox.Show("Failed to insert data.");
                    }
                }
            }



           
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton5_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton6_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void label14_Click(object sender, EventArgs e)
        {

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {

        }

        private void label15_Click(object sender, EventArgs e)
        {

        }

        private void label16_Click(object sender, EventArgs e)
        {

        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox10_TextChanged(object sender, EventArgs e)
        {

        }

        private void label17_Click(object sender, EventArgs e)
        {

        }

        private void textBox11_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form4_Load(object sender, EventArgs e)
        {

        }
    }
}
