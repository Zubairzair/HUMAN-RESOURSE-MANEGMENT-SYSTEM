﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace HRM
{
    public partial class Form9 : Form
    {
        string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\PMLS\Desktop\HRM.accdb";
        OleDbConnection conn;//for built connection between form1 and data base
        OleDbCommand cmd;
        OleDbDataAdapter dataAdapter;//for implimentation of quries
        OleDbDataReader reader;
        DataTable dt;// for get table of data base
        public Form9()
        {
            InitializeComponent();
        }
        void Zubair8571()
        {
            conn = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\\Users\\PMLS\\Desktop\\HRM.accdb");
            dt = new DataTable();
            dataAdapter = new OleDbDataAdapter("SELECT * FROM employ", conn);
            conn.Open();// for open database
            dataAdapter.Fill(dt);
            dataGridView1.DataSource = dt;//for print of database on gridview 
            conn.Close();// for clodse database connection
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
            Form1   form = new Form1();
            form.ShowDialog();
        }

        private void Form9_Load(object sender, EventArgs e)
        {
            Zubair8571();
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label29_Click(object sender, EventArgs e)
        {

        }

        private void label24_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellEnter(object sender, DataGridViewCellEventArgs e)
        {
   
           idbox.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
           namebox.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            fnamebox.Text=dataGridView1.CurrentRow.Cells[2].Value.ToString();
            cnicbox.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
             dateTimePicker1.Text= dataGridView1.CurrentRow.Cells[4].Value.ToString();
            phonebox.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();
            emailbox.Text = dataGridView1.CurrentRow.Cells[6].Value.ToString();
            areabox.Text = dataGridView1.CurrentRow.Cells[7].Value.ToString();
            genderbox.Text = dataGridView1.CurrentRow.Cells[8].Value.ToString();
            mstatusbox.Text = dataGridView1.CurrentRow.Cells[9].Value.ToString();
            districtbox.Text = dataGridView1.CurrentRow.Cells[10].Value.ToString();
            nationalitybox.Text = dataGridView1.CurrentRow.Cells[11].Value.ToString();
            educationbox.Text = dataGridView1.CurrentRow.Cells[12].Value.ToString();
            experiencebox.Text = dataGridView1.CurrentRow.Cells[13].Value.ToString();
            dateTimePicker2.Text = dataGridView1.CurrentRow.Cells[14].Value.ToString();
            postbox.Text = dataGridView1.CurrentRow.Cells[15].Value.ToString();
           scalebox.Text = dataGridView1.CurrentRow.Cells[16].Value.ToString();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            string query =
"UPDATE employ SET EmpName=@name, fname=@FNAME, CNIC=@cnic,  DOB=@dob, phone=@PHONE,Email=@email, Area=@area, gender=@GENDER,  Mstatus=@mstatus, District=@district," +
"Nationality=@nationality, education=@EDUCATION, experience=@EXPERIENCE,startdate=@Startdate,post=@Post,scale=@Scale WHERE EmpID=@id";
            cmd = new OleDbCommand(query, conn);
            cmd.Parameters.AddWithValue("@name", namebox.Text);
            cmd.Parameters.AddWithValue("@FNAME", fnamebox.Text);
            cmd.Parameters.AddWithValue("@cnic", cnicbox.Text);
            cmd.Parameters.AddWithValue("@dob", dateTimePicker1.Value);
            cmd.Parameters.AddWithValue("=@PHONE", phonebox.Text);
            cmd.Parameters.AddWithValue("@email", emailbox.Text);
            cmd.Parameters.AddWithValue("@area,", areabox.Text);
            cmd.Parameters.AddWithValue("@GENDER", genderbox.Text);
            cmd.Parameters.AddWithValue("@mstatus", mstatusbox.Text);
            cmd.Parameters.AddWithValue("@district", districtbox.Text);
            cmd.Parameters.AddWithValue("@nationality",nationalitybox.Text);
            cmd.Parameters.AddWithValue("@EDUCATION", educationbox.Text);
            cmd.Parameters.AddWithValue("@EXPERIENCE",experiencebox.Text);
            cmd.Parameters.AddWithValue("@Startdate,", dateTimePicker2.Value);
             cmd.Parameters.AddWithValue("@Post", postbox.Text);
            cmd.Parameters.AddWithValue("=@Scale",scalebox.Text);
            cmd.Parameters.AddWithValue("@id", Convert.ToInt32(idbox.Text));
            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
            MessageBox.Show("Congradulations, your Data updated successfuly.Click Ok to view");
            Zubair8571();
            idbox.Clear();
            namebox.Clear();
            fnamebox.Clear();
            cnicbox.Clear();
            phonebox.Clear();
            emailbox.Clear();
            areabox.Clear();
            genderbox.Clear();
            mstatusbox.Clear();
            districtbox.Clear();
            nationalitybox.Clear();
            educationbox.Clear();   
            experiencebox.Clear();  
            postbox.Clear();
            scalebox.Clear();

        }

        private void idbox_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Realy, Are you want to Delete this record? \n\n Please note that this" +
               " record will be delete permanently", "Task Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            { //M.zubair8571
                string query =
                                                    "DELETE FROM employ  WHERE EmpID=@id";
                cmd = new OleDbCommand(query, conn);
                cmd.Parameters.AddWithValue("@id", Convert.ToInt32(idbox.Text));
                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
                MessageBox.Show("Okay , your Data deleted successfuly.Click Ok to view ");

                Zubair8571();
                idbox.Clear();
                namebox.Clear();
                fnamebox.Clear();
                cnicbox.Clear();
                phonebox.Clear();
                emailbox.Clear();
                areabox.Clear();
                genderbox.Clear();
                mstatusbox.Clear();
                districtbox.Clear();
                nationalitybox.Clear();
                educationbox.Clear();
                experiencebox.Clear();
                postbox.Clear();
                scalebox.Clear();
            }
            else
            {
                MessageBox.Show("Okay your Data is Safe, not deleted \n \n Be Happy", "Task Status", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {


            
            
                string searchName =searhbox.Text.Trim();

                if (!string.IsNullOrEmpty(searchName))
                {
                    // string connectionString = "your_connection_string_here";
                    string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\PMLS\Desktop\HRM.accdb;";  

                    using (OleDbConnection connection = new OleDbConnection(connectionString))
                    {
                        string query = "SELECT EmpID, EmpName, fname, CNIC, DOB, phone, Email, Area, " +
                                       "gender, Mstatus, District, Nationality, education, experience, " +
                                       "startdate, post, scale, * FROM employ WHERE EmpName = @searchName";

                        using (OleDbDataAdapter adapter = new OleDbDataAdapter(query, connection))
                        {
                            adapter.SelectCommand.Parameters.AddWithValue("@searchName", searchName);
                            DataTable dataTable = new DataTable();

                            connection.Open(); // Open the connection before executing the command
                            adapter.Fill(dataTable);

                            if (dataTable.Rows.Count > 0)
                            {
                                // Name found, display the record on GridView
                                dataGridView1.DataSource = dataTable;
                            }
                            else
                            {
                                // Name not found, display a message
                                MessageBox.Show("Record not found.", "Search Result", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Please enter a name to search.", "Search Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
       
        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void label27_Click(object sender, EventArgs e)
        {

        }
    }
    }




